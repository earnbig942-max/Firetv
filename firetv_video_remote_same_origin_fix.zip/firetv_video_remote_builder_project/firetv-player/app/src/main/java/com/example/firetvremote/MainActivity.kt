package com.example.firetvremote

import android.app.Activity
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.Bundle
import android.text.format.Formatter
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startService(Intent(this, ReceiverService::class.java))
        val wifi = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION")
        val ip = Formatter.formatIpAddress(wifi.connectionInfo.ipAddress)
        val text = TextView(this).apply {
            this.text = "Fire TV Video Receiver\n\nOpen this on your phone: http://$ip:8080/\n\nUse the remote page served by this Fire TV.\nKeep this app open to receive commands.\nAuthentication: OFF"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(android.graphics.Color.WHITE)
            setPadding(32, 32, 32, 32)
        }
        val layout = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setBackgroundColor(android.graphics.Color.rgb(16, 19, 27))
            addView(text)
        }
        setContentView(layout)
    }
}
