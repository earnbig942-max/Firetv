package com.example.firetvremote

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.widget.FrameLayout
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.ui.PlayerView

class PlayerActivity : Activity() {
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        val playerView = PlayerView(this)
        playerView.layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        setContentView(playerView)
        val p = ExoPlayer.Builder(this).build()
        player = p
        playerView.player = p
        loadUrl(intent.getStringExtra("url"))
    }

    private fun loadUrl(url: String?) {
        if (url.isNullOrBlank()) return
        player?.setMediaItem(MediaItem.fromUri(url))
        player?.prepare()
        player?.playWhenReady = true
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        loadUrl(intent.getStringExtra("url"))
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }

    companion object {
        @Volatile private var current: PlayerActivity? = null
        fun stopPlayback() { current?.runOnUiThread { current?.finish() } }
    }

    override fun onResume() { super.onResume(); current = this }
    override fun onPause() { if (current === this) current = null; super.onPause() }
}
