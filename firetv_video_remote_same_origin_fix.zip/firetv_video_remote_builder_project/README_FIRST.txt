FIRE TV VIDEO REMOTE - SOURCE PROJECT

Open/import the ROOT folder containing settings.gradle.kts in an Android Gradle builder.
Build task: :firetv-player:app:assembleDebug
APK output: firetv-player/app/build/outputs/apk/debug/app-debug.apk

This is source code, not a prebuilt APK. It requires Gradle 8.9, Android Gradle Plugin 8.7.3,
Kotlin 2.0.21, JDK 17, Android SDK 35, and internet access for dependencies.
This package does not contain gradlew or gradle-wrapper.jar; use a builder with Gradle installed
or ask it to generate the Gradle wrapper.

The phone controller is phone-remote/index.html and can be packaged separately using HTML-to-APK.
Phone and Fire TV must share Wi-Fi. Commands go to Fire TV port 8080; video streams directly
from the URL to Fire TV. Replace the default token in ReceiverService.kt and the HTML before use.
Android/Fire OS may block launching the player while YouTube is foregrounded; this is not guaranteed.


IMPORTANT CONNECTION FIX:
Open http://FIRE_TV_IP:8080/ directly in the phone browser. The Fire TV now serves the remote page itself. Do NOT open phone-remote/index.html as the active controller, because Android content:// pages can trigger browser cross-origin/private-network restrictions.
