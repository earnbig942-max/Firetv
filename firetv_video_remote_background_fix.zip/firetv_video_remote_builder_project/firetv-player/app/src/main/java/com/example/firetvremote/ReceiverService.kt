package com.example.firetvremote

import android.app.Service
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.content.Intent
import android.os.IBinder
import fi.iki.elonen.NanoHTTPD
import org.json.JSONObject

class ReceiverService : Service() {
    private var server: ReceiverHttpServer? = null

    override fun onCreate() {
        super.onCreate()
        startReceiverForeground()
        try {
            if (server == null) {
                server = ReceiverHttpServer(8080) { path, body ->
                    when (path) {
                        "/status" -> JSONObject().put("ok", true).put("auth", false).toString()
                        "/play" -> {
                            val url = JSONObject(body).optString("url", "")
                            if (!url.startsWith("http://") && !url.startsWith("https://")) throw IllegalArgumentException("Invalid video URL")
                            val intent = Intent(this, PlayerActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                                putExtra("url", url)
                            }
                            startActivity(intent)
                            JSONObject().put("ok", true).put("message", "Playback requested").toString()
                        }
                        "/stop" -> {
                            PlayerActivity.stopPlaybackAndReturnToPreviousApp()
                            JSONObject().put("ok", true).toString()
                        }
                        else -> throw NoSuchElementException("Not found")
                    }
                }
                server?.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
            }
        } catch (_: Exception) { }
    }

    private fun startReceiverForeground() {
        val channelId = "firetv_receiver_channel"
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Fire TV video receiver",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Keeps the phone-to-TV video receiver available" }
            manager.createNotificationChannel(channel)
        }
        val notification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, channelId)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }.setSmallIcon(android.R.drawable.stat_sys_upload_done)
            .setContentTitle("Fire TV receiver is active")
            .setContentText("Listening for phone commands on port 8080")
            .setOngoing(true)
            .build()
        startForeground(1001, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        server?.stop()
        server = null
        super.onDestroy()
    }
}

private class ReceiverHttpServer(port: Int, private val handler: (String, String) -> String) : NanoHTTPD("0.0.0.0", port) {
    // The controller is served by the Fire TV itself. Opening http://FIRE_TV_IP:8080/
    // makes the page and API same-origin, avoiding Chrome CORS/PNA restrictions
    // that affect HTML opened from content:// or file:// on Android.
    private val controllerHtml = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Fire TV Video Remote</title><style>
*{box-sizing:border-box}body{font-family:Arial,sans-serif;background:#10131b;color:#fff;margin:0;padding:22px}main{max-width:560px;margin:auto}label{display:block;margin:16px 0 6px;color:#cbd5e1}input{width:100%;padding:14px;border:1px solid #475569;border-radius:10px;background:#1e293b;color:white;font-size:16px}button{padding:14px 18px;border:0;border-radius:10px;font-size:16px;font-weight:bold;margin:12px 8px 0 0;background:#38bdf8;color:#082f49}.stop{background:#fb7185}#status{color:#a7f3d0;min-height:24px}small{color:#cbd5e1}
</style></head><body><main><h1>Fire TV Video Remote</h1>
<p>Connected to Fire TV receiver at <b id="host"></b></p>
<label>Direct video URL (MP4 or HLS .m3u8)</label><input id="url" type="url" placeholder="https://example.com/video.mp4" autocomplete="url">
<button onclick="connect()">Connect</button><button onclick="playVideo()">Play video</button><button class="stop" onclick="stopVideo()">Stop</button>
<p id="status">Ready. Paste a direct video URL.</p><small>Phone and Fire TV must share Wi-Fi. Video streams directly from the URL to Fire TV.</small></main>
<script>
const base=window.location.origin;const el=id=>document.getElementById(id);el('host').textContent=window.location.host;
async function req(path,data){const options=data?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}:{method:'GET'};const r=await fetch(base+path,options);const t=await r.text();if(!r.ok)throw Error(t||('HTTP '+r.status));return t}
async function connect(){try{await req('/status');el('status').textContent='Connected to Fire TV.'}catch(e){el('status').textContent='Connection failed: '+e.message}}
async function playVideo(){try{const u=el('url').value.trim();if(!(u.startsWith('http://')||u.startsWith('https://')))throw Error('Enter a valid http:// or https:// video URL');await req('/play',{url:u});el('status').textContent='Play command sent.'}catch(e){el('status').textContent='Error: '+e.message}}
async function stopVideo(){try{await req('/stop');el('status').textContent='Stop command sent.'}catch(e){el('status').textContent='Error: '+e.message}}
</script></body></html>"""

    override fun serve(session: IHTTPSession): Response {
        return try {
            val method = session.method
            val path = session.uri
            if (method == Method.GET && (path == "/" || path == "/index.html")) {
                newFixedLengthResponse(Response.Status.OK, "text/html; charset=utf-8", controllerHtml)
            } else if (method == Method.OPTIONS) {
                newFixedLengthResponse(Response.Status.OK, "text/plain", "")
            } else {
                var body = ""
                if (method == Method.POST) {
                    val files = HashMap<String, String>()
                    session.parseBody(files)
                    body = files["postData"] ?: ""
                }
                val result = handler(path, body)
                newFixedLengthResponse(Response.Status.OK, "application/json; charset=utf-8", result)
            }
        } catch (e: NoSuchElementException) {
            newFixedLengthResponse(Response.Status.NOT_FOUND, "application/json", "{\"error\":\"Not found\"}")
        } catch (e: Exception) {
            val msg = (e.message ?: "Bad request").replace("\\", "\\\\").replace("\"", "\\\"")
            newFixedLengthResponse(Response.Status.BAD_REQUEST, "application/json", "{\"error\":\"$msg\"}")
        }
    }
}
