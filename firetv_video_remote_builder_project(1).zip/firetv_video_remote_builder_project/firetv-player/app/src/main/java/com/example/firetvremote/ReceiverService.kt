package com.example.firetvremote

import android.app.Service
import android.content.Intent
import android.os.IBinder
import fi.iki.elonen.NanoHTTPD
import org.json.JSONObject

class ReceiverService : Service() {
    private var server: ReceiverHttpServer? = null

    override fun onCreate() {
        super.onCreate()
        try {
            if (server == null) {
                server = ReceiverHttpServer(8080) { path, body ->
                    when (path) {
                        "/status" -> JSONObject().put("ok", true).put("auth", false).toString()
                        "/play" -> {
                            val url = JSONObject(body).optString("url", "")
                            if (!url.startsWith("http://") && !url.startsWith("https://")) throw IllegalArgumentException("Invalid video URL")
                            val intent = Intent(this, PlayerActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                                putExtra("url", url)
                            }
                            startActivity(intent)
                            JSONObject().put("ok", true).put("message", "Playback requested").toString()
                        }
                        "/stop" -> {
                            PlayerActivity.stopPlayback()
                            JSONObject().put("ok", true).toString()
                        }
                        else -> throw NoSuchElementException("Not found")
                    }
                }
                server?.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
            }
        } catch (_: Exception) { }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        server?.stop()
        server = null
        super.onDestroy()
    }
}

private class ReceiverHttpServer(port: Int, private val handler: (String, String) -> String) : NanoHTTPD("0.0.0.0", port) {
    override fun serve(session: IHTTPSession): Response {
        return try {
            val method = session.method
            val path = session.uri
            if (method == Method.OPTIONS) {
                newFixedLengthResponse(Response.Status.OK, "text/plain", "").apply { addCorsHeaders() }
            } else {
                var body = ""
                if (method == Method.POST) {
                    val files = HashMap<String, String>()
                    session.parseBody(files)
                    body = files["postData"] ?: ""
                }
                val result = handler(path, body)
                newFixedLengthResponse(Response.Status.OK, "application/json; charset=utf-8", result).apply { addCorsHeaders() }
            }
        } catch (e: NoSuchElementException) {
            newFixedLengthResponse(Response.Status.NOT_FOUND, "application/json", "{\"error\":\"Not found\"}").apply { addCorsHeaders() }
        } catch (e: Exception) {
            val msg = (e.message ?: "Bad request").replace("\\", "\\\\").replace("\"", "\\\"")
            newFixedLengthResponse(Response.Status.BAD_REQUEST, "application/json", "{\"error\":\"$msg\"}").apply { addCorsHeaders() }
        }
    }

    private fun Response.addCorsHeaders() {
        addHeader("Access-Control-Allow-Origin", "*")
        addHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        addHeader("Access-Control-Allow-Headers", "Content-Type")
    }
}
