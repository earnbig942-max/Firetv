package com.example.firetvremote

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.widget.FrameLayout
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.ui.PlayerView

class PlayerActivity : Activity() {
    private var playerView: PlayerView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        current = this
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        val view = PlayerView(this).apply {
            useController = false
            setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
            setKeepContentOnPlayerReset(true)
            setShutterBackgroundColor(Color.BLACK)
            layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        }
        playerView = view
        setContentView(view)
        ReceiverServiceHolder.attachCurrentPlayer(this)
    }

    fun attach(player: ExoPlayer?) {
        runOnUiThread { playerView?.player = player }
    }

    override fun onDestroy() {
        if (current === this) current = null
        playerView?.player = null
        playerView = null
        super.onDestroy()
    }

    companion object {
        @Volatile private var current: PlayerActivity? = null

        fun attachPlayer(player: ExoPlayer) {
            current?.attach(player)
        }

        fun closePlayer() {
            val activity = current ?: return
            activity.runOnUiThread { if (!activity.isFinishing) activity.finishAndRemoveTask() }
        }
    }
}

/** Small bridge so the activity can attach the service-owned player without owning its lifecycle. */
private object ReceiverServiceHolder {
    fun attachCurrentPlayer(activity: PlayerActivity) {
        val service = ReceiverService.instance
        activity.attach(service?.activePlayer)
    }
}
