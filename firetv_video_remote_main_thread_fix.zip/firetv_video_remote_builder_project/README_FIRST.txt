FIRE TV VIDEO REMOTE - BACKGROUND RECEIVER UPDATE

Build task: :firetv-player:app:assembleDebug
APK output: firetv-player/app/build/outputs/apk/debug/app-debug.apk

WHAT CHANGED
- Receiver runs as a foreground service with an ongoing low-importance notification.
- Opening the app starts the service and immediately closes the launcher screen.
- Receiver service is configured to continue when its activity/task is removed.
- A boot receiver attempts to restart the service after device boot (Fire OS may restrict this).
- Stop closes/removes the receiver task instead of revealing the receiver launcher screen.
- Remote page remains hosted at http://FIRE_TV_IP:8080/ and authentication is OFF.

IMPORTANT LIMITS
- Android/Fire OS may stop services because of user force-stop, system restrictions, or memory pressure.
- Boot auto-start is best-effort and is not guaranteed on every Fire TV model/Fire OS version.
- The ongoing notification is normal for a persistent foreground service. The app stays in the Apps list so it can be opened manually if needed.
- This is source code, not a prebuilt APK. Build with JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Android SDK 35.


Playback update (v1.1): the receiver prepares the next video in its foreground service. The current playback is left running during preparation; when ExoPlayer reports STATE_READY, the receiver pauses the previous media session and opens a controls-hidden player. Stop restores the previous in-app player when one exists, or sends a media-play key to the previously active app. Android/Fire OS media-key routing is device/app dependent, so resuming an unrelated app cannot be guaranteed on every device.


NEW: STOP BACKGROUND RECEIVER BUTTON
The phone remote now has a "Stop background receiver" button. Press it to stop the Fire TV HTTP server and foreground service. After stopping it, the phone remote will no longer connect. To use it again, reopen the Fire TV Video Receiver app on the TV. This is different from the regular Stop button, which only stops the current video.
