package com.example.firetvremote

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import java.net.NetworkInterface

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startService(Intent(this, ReceiverService::class.java))
        val ip = try {
            NetworkInterface.getNetworkInterfaces().toList()
                .flatMap { it.inetAddresses.toList() }
                .firstOrNull { !it.isLoopbackAddress && it.hostAddress?.contains(':') == false }
                ?.hostAddress ?: "Find IP in Fire TV network settings"
        } catch (_: Exception) { "Find IP in Fire TV network settings" }
        setContentView(TextView(this).apply {
            text = "Fire TV Video Receiver\n\nPhone remote: http://$ip:8080\n\nKeep this app open to receive commands."
            textSize = 22f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(32, 32, 32, 32)
        })
    }
}
