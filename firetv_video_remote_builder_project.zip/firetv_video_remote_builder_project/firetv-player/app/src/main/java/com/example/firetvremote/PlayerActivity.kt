package com.example.firetvremote

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.view.View
import android.widget.FrameLayout
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.ui.PlayerView

class PlayerActivity : Activity() {
    companion object { const val ACTION_STOP = "com.example.firetvremote.STOP_PLAYBACK" }
    private var player: ExoPlayer? = null
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { finish() }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        registerReceiver(receiver, IntentFilter(ACTION_STOP))
        val pv = PlayerView(this)
        setContentView(FrameLayout(this).apply { addView(pv, FrameLayout.LayoutParams(-1, -1)) })
        player = ExoPlayer.Builder(this).build().also { p ->
            pv.player = p
            intent.getStringExtra("url")?.let { p.setMediaItem(MediaItem.fromUri(it)); p.prepare(); p.playWhenReady = true }
        }
    }
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent); setIntent(intent)
        intent.getStringExtra("url")?.let { player?.setMediaItem(MediaItem.fromUri(it)); player?.prepare(); player?.playWhenReady = true }
    }
    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        player?.release(); player = null
        super.onDestroy()
    }
}
