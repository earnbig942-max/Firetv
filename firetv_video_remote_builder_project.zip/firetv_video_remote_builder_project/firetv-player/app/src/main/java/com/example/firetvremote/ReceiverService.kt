package com.example.firetvremote

import android.app.Service
import android.content.Intent
import android.os.IBinder
import fi.iki.elonen.NanoHTTPD
import org.json.JSONObject

class ReceiverService : Service() {
    private var server: RemoteServer? = null
    private val token = "change-this-token"

    override fun onCreate() {
        super.onCreate()
        server = RemoteServer()
        try { server?.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false) } catch (_: Exception) { stopSelf() }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { server?.stop(); server = null; super.onDestroy() }

    private inner class RemoteServer : NanoHTTPD(8080) {
        override fun serve(session: IHTTPSession): Response {
            val headers = mapOf(
                "Access-Control-Allow-Origin" to "*",
                "Access-Control-Allow-Methods" to "GET, POST, OPTIONS",
                "Access-Control-Allow-Headers" to "Content-Type, Authorization"
            )
            fun reply(status: Response.IStatus, body: String): Response {
                val r = newFixedLengthResponse(status, "application/json", body)
                headers.forEach { (k, v) -> r.addHeader(k, v) }
                return r
            }
            if (session.method == Method.OPTIONS) return reply(Response.Status.OK, "{}")
            if ((session.headers["authorization"] ?: "") != "Bearer $token")
                return reply(Response.Status.UNAUTHORIZED, "{\"error\":\"Unauthorized\"}")
            return when (session.uri) {
                "/status" -> reply(Response.Status.OK, "{\"ready\":true}")
                "/play" -> {
                    val body = HashMap<String, String>()
                    try { session.parseBody(body) } catch (_: Exception) {}
                    val url = try { JSONObject(body["postData"] ?: "{}").optString("url") } catch (_: Exception) { "" }
                    if (!url.startsWith("http://") && !url.startsWith("https://")) {
                        reply(Response.Status.BAD_REQUEST, "{\"error\":\"Valid http/https URL required\"}")
                    } else {
                        val i = Intent(this@ReceiverService, PlayerActivity::class.java)
                            .putExtra("url", url).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        try {
                            startActivity(i)
                            reply(Response.Status.OK, "{\"accepted\":true}")
                        } catch (_: Exception) {
                            reply(Response.Status.FORBIDDEN, "{\"error\":\"Fire OS blocked player launch\"}")
                        }
                    }
                }
                "/stop" -> {
                    sendBroadcast(Intent(PlayerActivity.ACTION_STOP))
                    reply(Response.Status.OK, "{\"stopped\":true}")
                }
                else -> reply(Response.Status.NOT_FOUND, "{\"error\":\"Not found\"}")
            }
        }
    }
}
